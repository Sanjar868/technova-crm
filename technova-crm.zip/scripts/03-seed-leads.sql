-- Insert sample leads
INSERT INTO leads (company, contact, email, phone, source, score, status, value, notes) VALUES
('StartupTech', 'Alex Wilson', 'alex.wilson@startuptech.com', '+1 (555) 111-2222', 'Website', 85, 'Qualified', 35000.00, 'Interested in ERP migration'),
('Manufacturing Co', 'Lisa Brown', 'lisa.brown@mfgco.com', '+1 (555) 333-4444', 'Referral', 70, 'Contacted', 50000.00, 'Needs WMS solution'),
('RetailTech Solutions', 'Mark Davis', 'mark.davis@retailtech.com', '+1 (555) 555-6666', 'Cold Call', 60, 'New', 25000.00, 'Small retail chain looking for CRM'),
('LogisticsPro', 'Sarah Kim', 'sarah.kim@logisticspro.com', '+1 (555) 777-8888', 'Trade Show', 75, 'Qualified', 45000.00, 'Warehouse management needs'),
('FinanceTech Corp', 'Tom Rodriguez', 'tom.rodriguez@financetech.com', '+1 (555) 999-1111', 'Social Media', 55, 'Contacted', 38000.00, 'Financial ERP requirements');
