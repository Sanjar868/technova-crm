-- Insert sample opportunities
INSERT INTO opportunities (title, company, contact, value, stage, probability, close_date, description) VALUES
('ERP Migration Project', 'Acme Corporation', 'John Smith', 45000.00, 'Negotiation', 75, '2024-02-15', 'Complete ERP system migration to cloud'),
('CRM Implementation', 'TechStart Inc', 'Sarah Johnson', 28500.00, 'Proposal', 50, '2024-02-28', 'New CRM system setup and training'),
('WMS Upgrade', 'Global Logistics', 'Mike Chen', 67200.00, 'Qualification', 40, '2024-03-15', 'Warehouse management system modernization'),
('Cloud Migration', 'RetailMax Solutions', 'Emily Davis', 52800.00, 'Closing', 90, '2024-02-10', 'Full infrastructure cloud migration'),
('ERP Modernization', 'Manufacturing Plus', 'Robert Wilson', 38900.00, 'Proposal', 60, '2024-03-01', 'Legacy ERP system replacement');
