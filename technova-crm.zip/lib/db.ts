import { neon } from "@neondatabase/serverless"

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is not set")
}

export const sql = neon(process.env.DATABASE_URL)

export interface Customer {
  id: number
  name: string
  contact: string
  email: string
  phone: string
  status: string
  value: number
  last_contact: string
  created_at: string
  updated_at: string
}

export interface Lead {
  id: number
  company: string
  contact: string
  email: string
  phone: string
  source: string
  score: number
  status: string
  value: number
  notes: string
  created_at: string
  updated_at: string
}

export interface Opportunity {
  id: number
  title: string
  company: string
  contact: string
  value: number
  stage: string
  probability: number
  close_date: string
  description: string
  created_at: string
  updated_at: string
}
