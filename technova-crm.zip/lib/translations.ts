export const translations = {
  en: {
    // Navigation
    dashboard: "Dashboard",
    customers: "Customers",
    leads: "Leads",
    opportunities: "Opportunities",
    services: "Services",
    settings: "Settings",

    // Dashboard
    dashboardTitle: "Dashboard",
    dashboardSubtitle: "Overview of your CRM performance",
    totalCustomers: "Total Customers",
    activeLeads: "Active Leads",
    monthlyRevenue: "Monthly Revenue",
    conversionRate: "Conversion Rate",
    fromLastMonth: "from last month",

    // Customer Management
    customerManagement: "Customer Management",
    customerManagementSubtitle: "Manage your customer relationships",
    addCustomer: "Add Customer",
    editCustomer: "Edit Customer",
    company: "Company",
    contact: "Contact",
    email: "Email",
    phone: "Phone",
    status: "Status",
    value: "Value",
    lastContact: "Last Contact",

    // Lead Management
    leadManagement: "Lead Management",
    leadManagementSubtitle: "Track and convert leads",
    addLead: "Add Lead",
    source: "Source",
    score: "Score",
    notes: "Notes",

    // Opportunities
    salesOpportunities: "Sales Opportunities",
    salesOpportunitiesSubtitle: "Monitor sales pipeline",
    addOpportunity: "Add Opportunity",
    title: "Title",
    stage: "Stage",
    probability: "Probability",
    closeDate: "Close Date",
    description: "Description",

    // Services
    cloudServices: "Cloud Services",
    cloudServicesSubtitle: "ERP, CRM & WMS Migration Services",
    addService: "Add Service",

    // Common
    search: "Search",
    filter: "Filter",
    edit: "Edit",
    delete: "Delete",
    cancel: "Cancel",
    save: "Save",
    add: "Add",
    update: "Update",
    close: "Close",

    // Status values
    active: "Active",
    lead: "Lead",
    proposal: "Proposal",
    closed: "Closed",
    qualified: "Qualified",
    contacted: "Contacted",
    new: "New",

    // Sources
    website: "Website",
    referral: "Referral",
    coldCall: "Cold Call",
    socialMedia: "Social Media",
    tradeShow: "Trade Show",

    // Stages
    qualification: "Qualification",
    negotiation: "Negotiation",
    closing: "Closing",

    // Messages
    customerAddedSuccess: "Customer added successfully",
    leadAddedSuccess: "Lead added successfully",
    opportunityAddedSuccess: "Opportunity added successfully",
    customerUpdatedSuccess: "Customer updated successfully",
    customerDeletedSuccess: "Customer deleted successfully",
    settingsSaved: "Settings Saved",
    settingsSavedDesc: "Your preferences have been updated successfully.",
    errorFetchingCustomers: "Failed to fetch customers",
    errorAddingCustomer: "Failed to add customer",
    errorUpdatingCustomer: "Failed to update customer",
    errorDeletingCustomer: "Failed to delete customer",

    // Dialogs
    addCustomerDesc: "Add a new customer to your CRM system.",
    addLeadDesc: "Add a new lead to track potential customers.",
    addOpportunityDesc: "Add a new sales opportunity.",
    editCustomerDesc: "Update customer information.",
    settingsDesc: "Manage your CRM system preferences.",

    // Settings
    generalSettings: "General Settings",
    emailNotifications: "Email Notifications",
    autoSave: "Auto-save Changes",
    displaySettings: "Display Settings",
    darkMode: "Dark Mode",
    compactView: "Compact View",
    dataManagement: "Data Management",
    exportCustomerData: "Export Customer Data",
    importCustomerData: "Import Customer Data",
    clearAllData: "Clear All Data",

    // Pipeline
    salesPipeline: "Sales Pipeline",
    salesPipelineDesc: "Current opportunities by stage",
    qualifiedLeads: "Qualified Leads",
    proposalSent: "Proposal Sent",

    // Activities
    recentActivities: "Recent Activities",
    recentActivitiesDesc: "Latest customer interactions",
    completed: "completed",
    sent: "sent",
    pending: "pending",

    // Services
    cloudMigrationServices: "Cloud Migration Services",
    cloudMigrationServicesDesc: "Our core service offerings for SMBs",
    erpMigration: "ERP Migration",
    erpMigrationDesc: "Enterprise Resource Planning system migration to cloud",
    crmMigration: "CRM Migration",
    crmMigrationDesc: "Customer Relationship Management system migration",
    wmsMigration: "WMS Migration",
    wmsMigrationDesc: "Warehouse Management System migration to cloud",
    activeProjects: "Active Projects",

    // Placeholders
    companyNamePlaceholder: "Company name",
    contactPersonPlaceholder: "Contact person",
    emailPlaceholder: "email@company.com",
    phonePlaceholder: "+1 (555) 123-4567",
    valuePlaceholder: "$25,000",
    notesPlaceholder: "Additional notes...",
    opportunityTitlePlaceholder: "Opportunity title",
    opportunityDescPlaceholder: "Opportunity description...",
    searchPlaceholder: "Search...",

    // Filters
    allCustomers: "All Customers",

    // Loading states
    adding: "Adding...",
    updating: "Updating...",

    // Confirmation
    deleteConfirmation: "Are you sure you want to delete this customer?",
  },
  uz: {
    // Navigation
    dashboard: "Boshqaruv paneli",
    customers: "Mijozlar",
    leads: "Potentsial mijozlar",
    opportunities: "Imkoniyatlar",
    services: "Xizmatlar",
    settings: "Sozlamalar",

    // Dashboard
    dashboardTitle: "Boshqaruv paneli",
    dashboardSubtitle: "CRM tizimingiz ishlashining umumiy ko'rinishi",
    totalCustomers: "Jami mijozlar",
    activeLeads: "Faol potentsial mijozlar",
    monthlyRevenue: "Oylik daromad",
    conversionRate: "Konversiya darajasi",
    fromLastMonth: "o'tgan oydan",

    // Customer Management
    customerManagement: "Mijozlarni boshqarish",
    customerManagementSubtitle: "Mijozlar bilan munosabatlarni boshqaring",
    addCustomer: "Mijoz qo'shish",
    editCustomer: "Mijozni tahrirlash",
    company: "Kompaniya",
    contact: "Aloqa",
    email: "Elektron pochta",
    phone: "Telefon",
    status: "Holat",
    value: "Qiymat",
    lastContact: "Oxirgi aloqa",

    // Lead Management
    leadManagement: "Potentsial mijozlarni boshqarish",
    leadManagementSubtitle: "Potentsial mijozlarni kuzatish va aylantirish",
    addLead: "Potentsial mijoz qo'shish",
    source: "Manba",
    score: "Ball",
    notes: "Eslatmalar",

    // Opportunities
    salesOpportunities: "Sotuv imkoniyatlari",
    salesOpportunitiesSubtitle: "Sotuv yo'nalishini kuzatish",
    addOpportunity: "Imkoniyat qo'shish",
    title: "Sarlavha",
    stage: "Bosqich",
    probability: "Ehtimollik",
    closeDate: "Yopilish sanasi",
    description: "Tavsif",

    // Services
    cloudServices: "Bulut xizmatlari",
    cloudServicesSubtitle: "ERP, CRM va WMS ko'chirish xizmatlari",
    addService: "Xizmat qo'shish",

    // Common
    search: "Qidirish",
    filter: "Filtr",
    edit: "Tahrirlash",
    delete: "O'chirish",
    cancel: "Bekor qilish",
    save: "Saqlash",
    add: "Qo'shish",
    update: "Yangilash",
    close: "Yopish",

    // Status values
    active: "Faol",
    lead: "Potentsial mijoz",
    proposal: "Taklif",
    closed: "Yopilgan",
    qualified: "Malakali",
    contacted: "Aloqaga chiqilgan",
    new: "Yangi",

    // Sources
    website: "Veb-sayt",
    referral: "Tavsiya",
    coldCall: "Sovuq qo'ng'iroq",
    socialMedia: "Ijtimoiy tarmoq",
    tradeShow: "Savdo ko'rgazmasi",

    // Stages
    qualification: "Malaka aniqlash",
    negotiation: "Muzokaralar",
    closing: "Yopish",

    // Messages
    customerAddedSuccess: "Mijoz muvaffaqiyatli qo'shildi",
    leadAddedSuccess: "Potentsial mijoz muvaffaqiyatli qo'shildi",
    opportunityAddedSuccess: "Imkoniyat muvaffaqiyatli qo'shildi",
    customerUpdatedSuccess: "Mijoz muvaffaqiyatli yangilandi",
    customerDeletedSuccess: "Mijoz muvaffaqiyatli o'chirildi",
    settingsSaved: "Sozlamalar saqlandi",
    settingsSavedDesc: "Sizning sozlamalaringiz muvaffaqiyatli yangilandi.",
    errorFetchingCustomers: "Mijozlarni olishda xatolik",
    errorAddingCustomer: "Mijoz qo'shishda xatolik",
    errorUpdatingCustomer: "Mijozni yangilashda xatolik",
    errorDeletingCustomer: "Mijozni o'chirishda xatolik",

    // Dialogs
    addCustomerDesc: "CRM tizimingizga yangi mijoz qo'shing.",
    addLeadDesc: "Potentsial mijozlarni kuzatish uchun yangi potentsial mijoz qo'shing.",
    addOpportunityDesc: "Yangi sotuv imkoniyatini qo'shing.",
    editCustomerDesc: "Mijoz ma'lumotlarini yangilang.",
    settingsDesc: "CRM tizimi sozlamalarini boshqaring.",

    // Settings
    generalSettings: "Umumiy sozlamalar",
    emailNotifications: "Elektron pochta xabarnomalar",
    autoSave: "Avtomatik saqlash",
    displaySettings: "Ko'rinish sozlamalari",
    darkMode: "Qorong'u rejim",
    compactView: "Ixcham ko'rinish",
    dataManagement: "Ma'lumotlarni boshqarish",
    exportCustomerData: "Mijozlar ma'lumotlarini eksport qilish",
    importCustomerData: "Mijozlar ma'lumotlarini import qilish",
    clearAllData: "Barcha ma'lumotlarni tozalash",

    // Pipeline
    salesPipeline: "Sotuv yo'nalishi",
    salesPipelineDesc: "Bosqich bo'yicha joriy imkoniyatlar",
    qualifiedLeads: "Malakali potentsial mijozlar",
    proposalSent: "Taklif yuborilgan",

    // Activities
    recentActivities: "So'nggi faoliyatlar",
    recentActivitiesDesc: "Mijozlar bilan so'nggi muloqotlar",
    completed: "bajarilgan",
    sent: "yuborilgan",
    pending: "kutilmoqda",

    // Services
    cloudMigrationServices: "Bulut ko'chirish xizmatlari",
    cloudMigrationServicesDesc: "Kichik va o'rta biznes uchun asosiy xizmat takliflarimiz",
    erpMigration: "ERP ko'chirish",
    erpMigrationDesc: "Korxona resurslarini rejalashtirish tizimini bulutga ko'chirish",
    crmMigration: "CRM ko'chirish",
    crmMigrationDesc: "Mijozlar bilan munosabatlarni boshqarish tizimini ko'chirish",
    wmsMigration: "WMS ko'chirish",
    wmsMigrationDesc: "Ombor boshqaruv tizimini bulutga ko'chirish",
    activeProjects: "Faol loyihalar",

    // Placeholders
    companyNamePlaceholder: "Kompaniya nomi",
    contactPersonPlaceholder: "Aloqa shaxsi",
    emailPlaceholder: "email@kompaniya.com",
    phonePlaceholder: "+998 (90) 123-45-67",
    valuePlaceholder: "$25,000",
    notesPlaceholder: "Qo'shimcha eslatmalar...",
    opportunityTitlePlaceholder: "Imkoniyat sarlavhasi",
    opportunityDescPlaceholder: "Imkoniyat tavsifi...",
    searchPlaceholder: "Qidirish...",

    // Filters
    allCustomers: "Barcha mijozlar",

    // Loading states
    adding: "Qo'shilmoqda...",
    updating: "Yangilanmoqda...",

    // Confirmation
    deleteConfirmation: "Haqiqatan ham bu mijozni o'chirmoqchimisiz?",
  },
}

export type Language = keyof typeof translations
export type TranslationKey = keyof typeof translations.en

export const getTranslation = (lang: Language, key: TranslationKey): string => {
  return translations[lang][key] || translations.en[key]
}
