"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import {
  Users,
  TrendingUp,
  DollarSign,
  Target,
  Phone,
  Mail,
  Calendar,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Building2,
  Cloud,
  Database,
  Settings,
  Edit,
  Trash2,
  Languages,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { type Language, type TranslationKey, getTranslation } from "@/lib/translations"

interface Customer {
  id: number
  name: string
  contact: string
  email: string
  phone: string
  status: string
  value: number
  last_contact: string
}

interface Lead {
  id: number
  company: string
  contact: string
  email: string
  phone: string
  source: string
  score: number
  status: string
  value: number
  notes: string
}

interface Opportunity {
  id: number
  title: string
  company: string
  contact: string
  value: number
  stage: string
  probability: number
  close_date: string
  description: string
}

export default function CRMDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null)
  const [filterStatus, setFilterStatus] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(false)
  const [isSettingsDialogOpen, setIsSettingsDialogOpen] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState<Language>("en")
  const { toast } = useToast()

  const t = (key: TranslationKey) => getTranslation(currentLanguage, key)

  const [customers, setCustomers] = useState<Customer[]>([])
  const [leads, setLeads] = useState<Lead[]>([])
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])

  const [newCustomer, setNewCustomer] = useState({
    name: "",
    contact: "",
    email: "",
    phone: "",
    status: "Lead",
    value: "",
    notes: "",
  })

  const [newLead, setNewLead] = useState({
    company: "",
    contact: "",
    email: "",
    phone: "",
    source: "Website",
    score: 50,
    status: "New",
    value: "",
    notes: "",
  })

  const [newOpportunity, setNewOpportunity] = useState({
    title: "",
    company: "",
    contact: "",
    value: "",
    stage: "Qualification",
    probability: 25,
    close_date: "",
    description: "",
  })

  // Fetch data from API
  const fetchCustomers = async () => {
    try {
      const params = new URLSearchParams()
      if (filterStatus !== "all") params.append("status", filterStatus)
      if (searchTerm) params.append("search", searchTerm)

      const response = await fetch(`/api/customers?${params}`)
      if (response.ok) {
        const data = await response.json()
        setCustomers(data)
      }
    } catch (error) {
      console.error("Error fetching customers:", error)
      toast({
        title: "Error",
        description: t("errorFetchingCustomers"),
        variant: "destructive",
      })
    }
  }

  const fetchLeads = async () => {
    try {
      const response = await fetch("/api/leads")
      if (response.ok) {
        const data = await response.json()
        setLeads(data)
      }
    } catch (error) {
      console.error("Error fetching leads:", error)
    }
  }

  const fetchOpportunities = async () => {
    try {
      const response = await fetch("/api/opportunities")
      if (response.ok) {
        const data = await response.json()
        setOpportunities(data)
      }
    } catch (error) {
      console.error("Error fetching opportunities:", error)
    }
  }

  useEffect(() => {
    fetchCustomers()
  }, [filterStatus, searchTerm])

  useEffect(() => {
    fetchLeads()
    fetchOpportunities()
  }, [])

  const metrics = [
    {
      title: t("totalCustomers"),
      value: customers.length.toString(),
      change: "+12.5%",
      icon: Users,
      color: "text-blue-600",
    },
    {
      title: t("activeLeads"),
      value: leads.length.toString(),
      change: "+8.2%",
      icon: Target,
      color: "text-green-600",
    },
    {
      title: t("monthlyRevenue"),
      value: `$${customers.reduce((sum, customer) => sum + (customer.value || 0), 0).toLocaleString()}`,
      change: "+23.1%",
      icon: DollarSign,
      color: "text-purple-600",
    },
    {
      title: t("conversionRate"),
      value: "24.8%",
      change: "+4.3%",
      icon: TrendingUp,
      color: "text-orange-600",
    },
  ]

  const recentActivities = [
    {
      id: 1,
      type: "call",
      customer: "Acme Corp",
      action: "Scheduled ERP migration consultation",
      time: "2 hours ago",
      status: t("completed"),
    },
    {
      id: 2,
      type: "email",
      customer: "TechStart Inc",
      action: "Sent CRM proposal and pricing",
      time: "4 hours ago",
      status: t("sent"),
    },
    {
      id: 3,
      type: "meeting",
      customer: "Global Logistics",
      action: "WMS system demo presentation",
      time: "1 day ago",
      status: t("completed"),
    },
    {
      id: 4,
      type: "call",
      customer: "RetailMax",
      action: "Follow-up on cloud migration timeline",
      time: "2 days ago",
      status: t("pending"),
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800"
      case "Lead":
        return "bg-blue-100 text-blue-800"
      case "Proposal":
        return "bg-yellow-100 text-yellow-800"
      case "Qualified":
        return "bg-purple-100 text-purple-800"
      case "Contacted":
        return "bg-orange-100 text-orange-800"
      case "New":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "call":
        return Phone
      case "email":
        return Mail
      case "meeting":
        return Calendar
      default:
        return Phone
    }
  }

  const handleAddCustomer = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/customers", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: newCustomer.name,
          contact: newCustomer.contact,
          email: newCustomer.email,
          phone: newCustomer.phone,
          status: newCustomer.status,
          value: Number.parseFloat(newCustomer.value.replace(/[$,]/g, "")) || 0,
        }),
      })

      if (response.ok) {
        await fetchCustomers()
        resetNewCustomer()
        setIsAddDialogOpen(false)
        toast({
          title: "Success",
          description: t("customerAddedSuccess"),
        })
      } else {
        throw new Error("Failed to add customer")
      }
    } catch (error) {
      console.error("Error adding customer:", error)
      toast({
        title: "Error",
        description: t("errorAddingCustomer"),
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleAddLead = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          company: newLead.company,
          contact: newLead.contact,
          email: newLead.email,
          phone: newLead.phone,
          source: newLead.source,
          score: newLead.score,
          status: newLead.status,
          value: Number.parseFloat(newLead.value.replace(/[$,]/g, "")) || 0,
          notes: newLead.notes,
        }),
      })

      if (response.ok) {
        await fetchLeads()
        resetNewLead()
        setIsAddDialogOpen(false)
        toast({
          title: "Success",
          description: t("leadAddedSuccess"),
        })
      } else {
        throw new Error("Failed to add lead")
      }
    } catch (error) {
      console.error("Error adding lead:", error)
      toast({
        title: "Error",
        description: "Failed to add lead",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleAddOpportunity = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/opportunities", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: newOpportunity.title,
          company: newOpportunity.company,
          contact: newOpportunity.contact,
          value: Number.parseFloat(newOpportunity.value.replace(/[$,]/g, "")) || 0,
          stage: newOpportunity.stage,
          probability: newOpportunity.probability,
          close_date: newOpportunity.close_date,
          description: newOpportunity.description,
        }),
      })

      if (response.ok) {
        await fetchOpportunities()
        resetNewOpportunity()
        setIsAddDialogOpen(false)
        toast({
          title: "Success",
          description: t("opportunityAddedSuccess"),
        })
      } else {
        throw new Error("Failed to add opportunity")
      }
    } catch (error) {
      console.error("Error adding opportunity:", error)
      toast({
        title: "Error",
        description: "Failed to add opportunity",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleEditCustomer = (customer: Customer) => {
    setEditingCustomer(customer)
    setNewCustomer({
      name: customer.name,
      contact: customer.contact,
      email: customer.email,
      phone: customer.phone,
      status: customer.status,
      value: customer.value.toString(),
      notes: "",
    })
    setIsEditDialogOpen(true)
  }

  const handleUpdateCustomer = async () => {
    if (!editingCustomer) return

    setLoading(true)
    try {
      const response = await fetch(`/api/customers/${editingCustomer.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: newCustomer.name,
          contact: newCustomer.contact,
          email: newCustomer.email,
          phone: newCustomer.phone,
          status: newCustomer.status,
          value: Number.parseFloat(newCustomer.value.replace(/[$,]/g, "")) || 0,
        }),
      })

      if (response.ok) {
        await fetchCustomers()
        setIsEditDialogOpen(false)
        setEditingCustomer(null)
        resetNewCustomer()
        toast({
          title: "Success",
          description: t("customerUpdatedSuccess"),
        })
      } else {
        throw new Error("Failed to update customer")
      }
    } catch (error) {
      console.error("Error updating customer:", error)
      toast({
        title: "Error",
        description: t("errorUpdatingCustomer"),
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteCustomer = async (customerId: number) => {
    if (!confirm(t("deleteConfirmation"))) return

    try {
      const response = await fetch(`/api/customers/${customerId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        await fetchCustomers()
        toast({
          title: "Success",
          description: t("customerDeletedSuccess"),
        })
      } else {
        throw new Error("Failed to delete customer")
      }
    } catch (error) {
      console.error("Error deleting customer:", error)
      toast({
        title: "Error",
        description: t("errorDeletingCustomer"),
        variant: "destructive",
      })
    }
  }

  const resetNewCustomer = () => {
    setNewCustomer({
      name: "",
      contact: "",
      email: "",
      phone: "",
      status: "Lead",
      value: "",
      notes: "",
    })
  }

  const resetNewLead = () => {
    setNewLead({
      company: "",
      contact: "",
      email: "",
      phone: "",
      source: "Website",
      score: 50,
      status: "New",
      value: "",
      notes: "",
    })
  }

  const resetNewOpportunity = () => {
    setNewOpportunity({
      title: "",
      company: "",
      contact: "",
      value: "",
      stage: "Qualification",
      probability: 25,
      close_date: "",
      description: "",
    })
  }

  const getAddButtonText = () => {
    switch (activeTab) {
      case "customers":
        return t("addCustomer")
      case "leads":
        return t("addLead")
      case "opportunities":
        return t("addOpportunity")
      case "services":
        return t("addService")
      default:
        return "Add New"
    }
  }

  const renderAddDialog = () => {
    if (activeTab === "customers") {
      return (
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t("addCustomer")}</DialogTitle>
            <DialogDescription>{t("addCustomerDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="company-name" className="text-right">
                {t("company")}
              </Label>
              <Input
                id="company-name"
                value={newCustomer.name}
                onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                className="col-span-3"
                placeholder={t("companyNamePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="contact-name" className="text-right">
                {t("contact")}
              </Label>
              <Input
                id="contact-name"
                value={newCustomer.contact}
                onChange={(e) => setNewCustomer({ ...newCustomer, contact: e.target.value })}
                className="col-span-3"
                placeholder={t("contactPersonPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                {t("email")}
              </Label>
              <Input
                id="email"
                type="email"
                value={newCustomer.email}
                onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                className="col-span-3"
                placeholder={t("emailPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone" className="text-right">
                {t("phone")}
              </Label>
              <Input
                id="phone"
                value={newCustomer.phone}
                onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                className="col-span-3"
                placeholder={t("phonePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="status" className="text-right">
                {t("status")}
              </Label>
              <Select
                value={newCustomer.status}
                onValueChange={(value) => setNewCustomer({ ...newCustomer, status: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Lead">{t("lead")}</SelectItem>
                  <SelectItem value="Proposal">{t("proposal")}</SelectItem>
                  <SelectItem value="Active">{t("active")}</SelectItem>
                  <SelectItem value="Closed">{t("closed")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="value" className="text-right">
                {t("value")}
              </Label>
              <Input
                id="value"
                value={newCustomer.value}
                onChange={(e) => setNewCustomer({ ...newCustomer, value: e.target.value })}
                className="col-span-3"
                placeholder={t("valuePlaceholder")}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              {t("cancel")}
            </Button>
            <Button type="submit" onClick={handleAddCustomer} disabled={loading}>
              {loading ? t("adding") : t("addCustomer")}
            </Button>
          </DialogFooter>
        </DialogContent>
      )
    }

    if (activeTab === "leads") {
      return (
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t("addLead")}</DialogTitle>
            <DialogDescription>{t("addLeadDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-company" className="text-right">
                {t("company")}
              </Label>
              <Input
                id="lead-company"
                value={newLead.company}
                onChange={(e) => setNewLead({ ...newLead, company: e.target.value })}
                className="col-span-3"
                placeholder={t("companyNamePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-contact" className="text-right">
                {t("contact")}
              </Label>
              <Input
                id="lead-contact"
                value={newLead.contact}
                onChange={(e) => setNewLead({ ...newLead, contact: e.target.value })}
                className="col-span-3"
                placeholder={t("contactPersonPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-email" className="text-right">
                {t("email")}
              </Label>
              <Input
                id="lead-email"
                type="email"
                value={newLead.email}
                onChange={(e) => setNewLead({ ...newLead, email: e.target.value })}
                className="col-span-3"
                placeholder={t("emailPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-phone" className="text-right">
                {t("phone")}
              </Label>
              <Input
                id="lead-phone"
                value={newLead.phone}
                onChange={(e) => setNewLead({ ...newLead, phone: e.target.value })}
                className="col-span-3"
                placeholder={t("phonePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-source" className="text-right">
                {t("source")}
              </Label>
              <Select value={newLead.source} onValueChange={(value) => setNewLead({ ...newLead, source: value })}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Website">{t("website")}</SelectItem>
                  <SelectItem value="Referral">{t("referral")}</SelectItem>
                  <SelectItem value="Cold Call">{t("coldCall")}</SelectItem>
                  <SelectItem value="Social Media">{t("socialMedia")}</SelectItem>
                  <SelectItem value="Trade Show">{t("tradeShow")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-value" className="text-right">
                {t("value")}
              </Label>
              <Input
                id="lead-value"
                value={newLead.value}
                onChange={(e) => setNewLead({ ...newLead, value: e.target.value })}
                className="col-span-3"
                placeholder={t("valuePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="lead-notes" className="text-right">
                {t("notes")}
              </Label>
              <Textarea
                id="lead-notes"
                value={newLead.notes}
                onChange={(e) => setNewLead({ ...newLead, notes: e.target.value })}
                className="col-span-3"
                placeholder={t("notesPlaceholder")}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              {t("cancel")}
            </Button>
            <Button type="submit" onClick={handleAddLead} disabled={loading}>
              {loading ? t("adding") : t("addLead")}
            </Button>
          </DialogFooter>
        </DialogContent>
      )
    }

    if (activeTab === "opportunities") {
      return (
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t("addOpportunity")}</DialogTitle>
            <DialogDescription>{t("addOpportunityDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-title" className="text-right">
                {t("title")}
              </Label>
              <Input
                id="opp-title"
                value={newOpportunity.title}
                onChange={(e) => setNewOpportunity({ ...newOpportunity, title: e.target.value })}
                className="col-span-3"
                placeholder={t("opportunityTitlePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-company" className="text-right">
                {t("company")}
              </Label>
              <Input
                id="opp-company"
                value={newOpportunity.company}
                onChange={(e) => setNewOpportunity({ ...newOpportunity, company: e.target.value })}
                className="col-span-3"
                placeholder={t("companyNamePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-contact" className="text-right">
                {t("contact")}
              </Label>
              <Input
                id="opp-contact"
                value={newOpportunity.contact}
                onChange={(e) => setNewOpportunity({ ...newOpportunity, contact: e.target.value })}
                className="col-span-3"
                placeholder={t("contactPersonPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-value" className="text-right">
                {t("value")}
              </Label>
              <Input
                id="opp-value"
                value={newOpportunity.value}
                onChange={(e) => setNewOpportunity({ ...newOpportunity, value: e.target.value })}
                className="col-span-3"
                placeholder="$50,000"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-stage" className="text-right">
                {t("stage")}
              </Label>
              <Select
                value={newOpportunity.stage}
                onValueChange={(value) => setNewOpportunity({ ...newOpportunity, stage: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Qualification">{t("qualification")}</SelectItem>
                  <SelectItem value="Proposal">{t("proposal")}</SelectItem>
                  <SelectItem value="Negotiation">{t("negotiation")}</SelectItem>
                  <SelectItem value="Closing">{t("closing")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-close-date" className="text-right">
                {t("closeDate")}
              </Label>
              <Input
                id="opp-close-date"
                type="date"
                value={newOpportunity.close_date}
                onChange={(e) => setNewOpportunity({ ...newOpportunity, close_date: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="opp-description" className="text-right">
                {t("description")}
              </Label>
              <Textarea
                id="opp-description"
                value={newOpportunity.description}
                onChange={(e) => setNewOpportunity({ ...newOpportunity, description: e.target.value })}
                className="col-span-3"
                placeholder={t("opportunityDescPlaceholder")}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              {t("cancel")}
            </Button>
            <Button type="submit" onClick={handleAddOpportunity} disabled={loading}>
              {loading ? t("adding") : t("addOpportunity")}
            </Button>
          </DialogFooter>
        </DialogContent>
      )
    }

    return (
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add New Item</DialogTitle>
          <DialogDescription>This feature will be available soon.</DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button onClick={() => setIsAddDialogOpen(false)}>{t("close")}</Button>
        </DialogFooter>
      </DialogContent>
    )
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-sm border-r">
        <div className="p-6">
          <div className="flex items-center gap-2">
            <Cloud className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-xl font-bold text-gray-900">TechNova</h1>
              <p className="text-sm text-gray-500">CRM Solutions</p>
            </div>
          </div>
        </div>

        <nav className="px-4 space-y-2">
          <Button
            variant={activeTab === "dashboard" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => setActiveTab("dashboard")}
          >
            <TrendingUp className="mr-2 h-4 w-4" />
            {t("dashboard")}
          </Button>
          <Button
            variant={activeTab === "customers" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => setActiveTab("customers")}
          >
            <Users className="mr-2 h-4 w-4" />
            {t("customers")}
          </Button>
          <Button
            variant={activeTab === "leads" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => setActiveTab("leads")}
          >
            <Target className="mr-2 h-4 w-4" />
            {t("leads")}
          </Button>
          <Button
            variant={activeTab === "opportunities" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => setActiveTab("opportunities")}
          >
            <DollarSign className="mr-2 h-4 w-4" />
            {t("opportunities")}
          </Button>
          <Button
            variant={activeTab === "services" ? "default" : "ghost"}
            className="w-full justify-start"
            onClick={() => setActiveTab("services")}
          >
            <Database className="mr-2 h-4 w-4" />
            {t("services")}
          </Button>
        </nav>

        <div className="absolute bottom-4 left-4 right-4 space-y-2">
          {/* Language Switcher */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="w-full justify-start">
                <Languages className="mr-2 h-4 w-4" />
                {currentLanguage === "en" ? "English" : "O'zbekcha"}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => setCurrentLanguage("en")}>🇺🇸 English</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setCurrentLanguage("uz")}>🇺🇿 O'zbekcha</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Dialog open={isSettingsDialogOpen} onOpenChange={setIsSettingsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" className="w-full justify-start">
                <Settings className="mr-2 h-4 w-4" />
                {t("settings")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>{t("settings")}</DialogTitle>
                <DialogDescription>{t("settingsDesc")}</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">{t("generalSettings")}</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="notifications">{t("emailNotifications")}</Label>
                        <input type="checkbox" id="notifications" defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="auto-save">{t("autoSave")}</Label>
                        <input type="checkbox" id="auto-save" defaultChecked />
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-2">{t("displaySettings")}</h4>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="dark-mode">{t("darkMode")}</Label>
                        <input type="checkbox" id="dark-mode" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="compact-view">{t("compactView")}</Label>
                        <input type="checkbox" id="compact-view" />
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-2">{t("dataManagement")}</h4>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start bg-transparent">
                        {t("exportCustomerData")}
                      </Button>
                      <Button variant="outline" className="w-full justify-start bg-transparent">
                        {t("importCustomerData")}
                      </Button>
                      <Button variant="outline" className="w-full justify-start text-red-600 bg-transparent">
                        {t("clearAllData")}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsSettingsDialogOpen(false)}>
                  {t("cancel")}
                </Button>
                <Button
                  type="submit"
                  onClick={() => {
                    setIsSettingsDialogOpen(false)
                    toast({
                      title: t("settingsSaved"),
                      description: t("settingsSavedDesc"),
                    })
                  }}
                >
                  {t("save")} Changes
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {activeTab === "dashboard" && t("dashboardTitle")}
                {activeTab === "customers" && t("customerManagement")}
                {activeTab === "leads" && t("leadManagement")}
                {activeTab === "opportunities" && t("salesOpportunities")}
                {activeTab === "services" && t("cloudServices")}
              </h2>
              <p className="text-gray-600">
                {activeTab === "dashboard" && t("dashboardSubtitle")}
                {activeTab === "customers" && t("customerManagementSubtitle")}
                {activeTab === "leads" && t("leadManagementSubtitle")}
                {activeTab === "opportunities" && t("salesOpportunitiesSubtitle")}
                {activeTab === "services" && t("cloudServicesSubtitle")}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder={t("searchPlaceholder")}
                  className="pl-10 w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    {getAddButtonText()}
                  </Button>
                </DialogTrigger>
                {renderAddDialog()}
              </Dialog>
            </div>
          </div>
        </header>

        <main className="p-6">
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              {/* Metrics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {metrics.map((metric, index) => {
                  const Icon = metric.icon
                  return (
                    <Card key={index}>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">{metric.title}</CardTitle>
                        <Icon className={`h-4 w-4 ${metric.color}`} />
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">{metric.value}</div>
                        <p className="text-xs text-green-600 font-medium">
                          {metric.change} {t("fromLastMonth")}
                        </p>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Sales Pipeline */}
                <Card>
                  <CardHeader>
                    <CardTitle>{t("salesPipeline")}</CardTitle>
                    <CardDescription>{t("salesPipelineDesc")}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{t("qualifiedLeads")}</span>
                        <span>$245,000</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{t("proposalSent")}</span>
                        <span>$180,000</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{t("negotiation")}</span>
                        <span>$95,000</span>
                      </div>
                      <Progress value={40} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{t("closing")}</span>
                        <span>$67,000</span>
                      </div>
                      <Progress value={25} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activities */}
                <Card>
                  <CardHeader>
                    <CardTitle>{t("recentActivities")}</CardTitle>
                    <CardDescription>{t("recentActivitiesDesc")}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentActivities.map((activity) => {
                        const Icon = getActivityIcon(activity.type)
                        return (
                          <div key={activity.id} className="flex items-start gap-3">
                            <div className="p-2 bg-blue-100 rounded-full">
                              <Icon className="h-4 w-4 text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900">{activity.customer}</p>
                              <p className="text-sm text-gray-600">{activity.action}</p>
                              <p className="text-xs text-gray-400">{activity.time}</p>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {activity.status}
                            </Badge>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Service Categories */}
              <Card>
                <CardHeader>
                  <CardTitle>{t("cloudMigrationServices")}</CardTitle>
                  <CardDescription>{t("cloudMigrationServicesDesc")}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <Building2 className="h-8 w-8 text-blue-600 mb-2" />
                      <h3 className="font-semibold">{t("erpMigration")}</h3>
                      <p className="text-sm text-gray-600">{t("erpMigrationDesc")}</p>
                      <div className="mt-2 text-sm font-medium text-blue-600">47 {t("activeProjects")}</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <Users className="h-8 w-8 text-green-600 mb-2" />
                      <h3 className="font-semibold">{t("crmMigration")}</h3>
                      <p className="text-sm text-gray-600">{t("crmMigrationDesc")}</p>
                      <div className="mt-2 text-sm font-medium text-green-600">32 {t("activeProjects")}</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <Database className="h-8 w-8 text-purple-600 mb-2" />
                      <h3 className="font-semibold">{t("wmsMigration")}</h3>
                      <p className="text-sm text-gray-600">{t("wmsMigrationDesc")}</p>
                      <div className="mt-2 text-sm font-medium text-purple-600">28 {t("activeProjects")}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "customers" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <DropdownMenu open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline">
                        <Filter className="mr-2 h-4 w-4" />
                        {t("filter")} {filterStatus !== "all" && `(${filterStatus})`}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem onClick={() => setFilterStatus("all")}>{t("allCustomers")}</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setFilterStatus("Active")}>{t("active")}</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setFilterStatus("Lead")}>{t("lead")}</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setFilterStatus("Proposal")}>{t("proposal")}</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setFilterStatus("Closed")}>{t("closed")}</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("company")}</TableHead>
                      <TableHead>{t("contact")}</TableHead>
                      <TableHead>{t("status")}</TableHead>
                      <TableHead>{t("value")}</TableHead>
                      <TableHead>{t("lastContact")}</TableHead>
                      <TableHead className="w-[50px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {customers.map((customer) => (
                      <TableRow key={customer.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{customer.name}</div>
                            <div className="text-sm text-gray-500">{customer.email}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{customer.contact}</div>
                            <div className="text-sm text-gray-500">{customer.phone}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(customer.status)}>{customer.status}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">${customer.value?.toLocaleString()}</TableCell>
                        <TableCell className="text-gray-500">
                          {new Date(customer.last_contact).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem onClick={() => handleEditCustomer(customer)}>
                                <Edit className="mr-2 h-4 w-4" />
                                {t("edit")}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDeleteCustomer(customer.id)}
                                className="text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                {t("delete")}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>
          )}

          {activeTab === "leads" && (
            <div className="space-y-6">
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("company")}</TableHead>
                      <TableHead>{t("contact")}</TableHead>
                      <TableHead>{t("source")}</TableHead>
                      <TableHead>{t("score")}</TableHead>
                      <TableHead>{t("status")}</TableHead>
                      <TableHead>{t("value")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leads.map((lead) => (
                      <TableRow key={lead.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{lead.company}</div>
                            <div className="text-sm text-gray-500">{lead.email}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{lead.contact}</div>
                            <div className="text-sm text-gray-500">{lead.phone}</div>
                          </div>
                        </TableCell>
                        <TableCell>{lead.source}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={lead.score} className="h-2 w-16" />
                            <span className="text-sm">{lead.score}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(lead.status)}>{lead.status}</Badge>
                        </TableCell>
                        <TableCell className="font-medium">${lead.value?.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>
          )}

          {activeTab === "opportunities" && (
            <div className="space-y-6">
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("title")}</TableHead>
                      <TableHead>{t("company")}</TableHead>
                      <TableHead>{t("value")}</TableHead>
                      <TableHead>{t("stage")}</TableHead>
                      <TableHead>{t("probability")}</TableHead>
                      <TableHead>{t("closeDate")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {opportunities.map((opportunity) => (
                      <TableRow key={opportunity.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{opportunity.title}</div>
                            <div className="text-sm text-gray-500">{opportunity.description}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{opportunity.company}</div>
                            <div className="text-sm text-gray-500">{opportunity.contact}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">${opportunity.value?.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(opportunity.stage)}>{opportunity.stage}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={opportunity.probability} className="h-2 w-16" />
                            <span className="text-sm">{opportunity.probability}%</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-500">
                          {new Date(opportunity.close_date).toLocaleDateString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </div>
          )}

          {activeTab === "services" && (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Service Management</h3>
                <p className="text-gray-600 mb-4">This section is under development</p>
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      {t("addService")}
                    </Button>
                  </DialogTrigger>
                  {renderAddDialog()}
                </Dialog>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Edit Customer Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t("editCustomer")}</DialogTitle>
            <DialogDescription>{t("editCustomerDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-company-name" className="text-right">
                {t("company")}
              </Label>
              <Input
                id="edit-company-name"
                value={newCustomer.name}
                onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                className="col-span-3"
                placeholder={t("companyNamePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-contact-name" className="text-right">
                {t("contact")}
              </Label>
              <Input
                id="edit-contact-name"
                value={newCustomer.contact}
                onChange={(e) => setNewCustomer({ ...newCustomer, contact: e.target.value })}
                className="col-span-3"
                placeholder={t("contactPersonPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-email" className="text-right">
                {t("email")}
              </Label>
              <Input
                id="edit-email"
                type="email"
                value={newCustomer.email}
                onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                className="col-span-3"
                placeholder={t("emailPlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-phone" className="text-right">
                {t("phone")}
              </Label>
              <Input
                id="edit-phone"
                value={newCustomer.phone}
                onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                className="col-span-3"
                placeholder={t("phonePlaceholder")}
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-status" className="text-right">
                {t("status")}
              </Label>
              <Select
                value={newCustomer.status}
                onValueChange={(value) => setNewCustomer({ ...newCustomer, status: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Lead">{t("lead")}</SelectItem>
                  <SelectItem value="Proposal">{t("proposal")}</SelectItem>
                  <SelectItem value="Active">{t("active")}</SelectItem>
                  <SelectItem value="Closed">{t("closed")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="edit-value" className="text-right">
                {t("value")}
              </Label>
              <Input
                id="edit-value"
                value={newCustomer.value}
                onChange={(e) => setNewCustomer({ ...newCustomer, value: e.target.value })}
                className="col-span-3"
                placeholder={t("valuePlaceholder")}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              {t("cancel")}
            </Button>
            <Button type="submit" onClick={handleUpdateCustomer} disabled={loading}>
              {loading ? t("updating") : t("update")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
