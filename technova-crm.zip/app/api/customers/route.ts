import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const search = searchParams.get("search")

    let customers

    if (status && status !== "all" && search) {
      // Both status and search filters
      customers = await sql`
        SELECT * FROM customers 
        WHERE status = ${status} 
        AND (name ILIKE ${`%${search}%`} OR contact ILIKE ${`%${search}%`} OR email ILIKE ${`%${search}%`})
        ORDER BY created_at DESC
      `
    } else if (status && status !== "all") {
      // Only status filter
      customers = await sql`
        SELECT * FROM customers 
        WHERE status = ${status}
        ORDER BY created_at DESC
      `
    } else if (search) {
      // Only search filter
      customers = await sql`
        SELECT * FROM customers 
        WHERE name ILIKE ${`%${search}%`} OR contact ILIKE ${`%${search}%`} OR email ILIKE ${`%${search}%`}
        ORDER BY created_at DESC
      `
    } else {
      // No filters
      customers = await sql`
        SELECT * FROM customers 
        ORDER BY created_at DESC
      `
    }

    return NextResponse.json(customers)
  } catch (error) {
    console.error("Error fetching customers:", error)
    return NextResponse.json({ error: "Failed to fetch customers" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, contact, email, phone, status, value } = body

    const result = await sql`
      INSERT INTO customers (name, contact, email, phone, status, value)
      VALUES (${name}, ${contact}, ${email}, ${phone}, ${status}, ${value})
      RETURNING *
    `

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("Error creating customer:", error)
    return NextResponse.json({ error: "Failed to create customer" }, { status: 500 })
  }
}
