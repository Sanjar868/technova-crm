import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"

export async function GET() {
  try {
    const opportunities = await sql`SELECT * FROM opportunities ORDER BY created_at DESC`
    return NextResponse.json(opportunities)
  } catch (error) {
    console.error("Error fetching opportunities:", error)
    return NextResponse.json({ error: "Failed to fetch opportunities" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, company, contact, value, stage, probability, close_date, description } = body

    const result = await sql`
      INSERT INTO opportunities (title, company, contact, value, stage, probability, close_date, description)
      VALUES (${title}, ${company}, ${contact}, ${value}, ${stage}, ${probability}, ${close_date}, ${description})
      RETURNING *
    `

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("Error creating opportunity:", error)
    return NextResponse.json({ error: "Failed to create opportunity" }, { status: 500 })
  }
}
